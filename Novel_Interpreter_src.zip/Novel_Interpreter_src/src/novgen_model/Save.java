package novgen_model;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;

import javax.swing.JOptionPane;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;


public class Save {
	
	static Element root;
	static Document document;
	public static void saveLibrary(Library library,String fileName) {
		root = new Element("library");
		
		document = new Document(root);
		for (int k=0;k<library.getStories().size();k++){
			Story story= library.getStories().get(k);
			Element elt_story = new Element("story");
			elt_story.setAttribute("title", story.getName());
			elt_story.setAttribute("author", story.getAuthor());
			elt_story.setAttribute("startPoint", story.getStartId());
			elt_story.setAttribute("length", String.valueOf(story.getLengthStory()));
			
			for (int i=0;i<story.getNodes().size();i++){
				StoryNode sn=story.getNodes().get(i);
				Element elt_node = new Element("node");
				//(String id,String textContent,String memory_add,String memory_remove,String condition,String to_nodes_id,boolean unique,String var){
				elt_node.setAttribute("id", sn.getId());
				elt_node.setAttribute("textContent", sn.getTextContent());
				elt_node.setAttribute("memoryAdd", sn.getMemory_add());
				elt_node.setAttribute("memoryRemove", sn.getMemory_remove());
				elt_node.setAttribute("memoryCondition", sn.getCondition());
				elt_node.setAttribute("nextNodes", sn.getTo_nodes_id());
				elt_node.setAttribute("unique",String.valueOf(sn.isUnique()));
				elt_node.setAttribute("variable", sn.getVar());
				
				String toNodes=sn.getTo_nodes_id();
				if (toNodes.length()>0){
					String strNodes[]= toNodes.split(",");
					for (int j=0;j<strNodes.length;j++){
						String str_condition=" COND: ";
						String str_mem_add=" - MEM-ADD: ";
						String str_mem_del=" - MEM-DEL: ";
						StoryNode n=new StoryNode(strNodes[j]);
						int index=story.getNodes().indexOf(n);
						if (index>=0){
							StoryNode next= story.getNodes().get(story.getNodes().indexOf(n));
							if (next.getCondition().length()==0)str_condition="";
							if (next.getMemory_add().length()==0)str_mem_add="";
							if (next.getMemory_remove().length()==0)str_mem_del="";
							
						}
					}
				}
				elt_story.addContent(elt_node);
			}
			for (int i=0;i<story.getListOfChoices().size();i++){
				Element elt_node = new Element("pathChosen");
				elt_node.setAttribute("id", story.getListOfChoices().get(i));
				elt_story.addContent(elt_node);
			}
			root.addContent(elt_story);
		}
		writeXMLfile(fileName);

		
	}
	
	public static void saveStory(Story story,String fileName,boolean export) {
		root = new Element("story");
		root.setAttribute("title", story.getName());
		root.setAttribute("author", story.getAuthor());
		root.setAttribute("startPoint", story.getStartId());
		root.setAttribute("length", String.valueOf(story.getLengthStory()));
		document = new Document(root);
		String strCmap="";
		for (int i=0;i<story.getNodes().size();i++){
			StoryNode sn=story.getNodes().get(i);
			Element elt_node = new Element("node");
			//(String id,String textContent,String memory_add,String memory_remove,String condition,String to_nodes_id,boolean unique,String var){
			elt_node.setAttribute("id", sn.getId());
			elt_node.setAttribute("textContent", sn.getTextContent());
			elt_node.setAttribute("memoryAdd", sn.getMemory_add());
			elt_node.setAttribute("memoryRemove", sn.getMemory_remove());
			elt_node.setAttribute("memoryCondition", sn.getCondition());
			elt_node.setAttribute("nextNodes", sn.getTo_nodes_id());
			elt_node.setAttribute("unique",String.valueOf(sn.isUnique()));
			elt_node.setAttribute("variable", sn.getVar());
			root.addContent(elt_node);
			String toNodes=sn.getTo_nodes_id();
			if (toNodes.length()>0){
				String strNodes[]= toNodes.split(",");
				for (int j=0;j<strNodes.length;j++){
					String str_condition=" COND: ";
					String str_mem_add=" - MEM-ADD: ";
					String str_mem_del=" - MEM-DEL: ";
					StoryNode n=new StoryNode(strNodes[j]);
					int index=story.getNodes().indexOf(n);
					if (index>=0){
						StoryNode next= story.getNodes().get(story.getNodes().indexOf(n));
						if (next.getCondition().length()==0)str_condition="";
						if (next.getMemory_add().length()==0)str_mem_add="";
						if (next.getMemory_remove().length()==0)str_mem_del="";
						strCmap=strCmap+sn.getId()+"\t"+str_condition+next.getCondition()+str_mem_add+next.getMemory_add()+str_mem_del+next.getMemory_remove()+" - UNIQUE: "+next.isUnique()+"\t"+strNodes[j]+"\n";
					}
				}
			}
			
		}
		for (int i=0;i<story.getListOfChoices().size();i++){
			Element elt_node = new Element("pathChosen");
			elt_node.setAttribute("id", story.getListOfChoices().get(i));
			root.addContent(elt_node);
		}
		if (export){
			writeTxtFile(fileName,strCmap);
		}else{
			writeXMLfile(fileName);
		}
		
	}
	
	private static void writeXMLfile(String fileName){
	   try{
	      XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
	      sortie.output(document, new FileOutputStream(fileName));
	      
	      JOptionPane.showMessageDialog(null,
                  "file saved to "+fileName);
          
	   }
	   catch (java.io.IOException e){
		   System.out.println(e.toString());
		   JOptionPane.showMessageDialog(null,
	                  "Error while exporting file");
	   }
	}
	
	public static void writeTxtFile(String fileName,String txt) {
		try {
			// Create file
			FileWriter fstream = new FileWriter(fileName);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(txt);
			// Close the output stream
			out.close();
			JOptionPane.showMessageDialog(null,
	                  "file exported to "+fileName);
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

}
