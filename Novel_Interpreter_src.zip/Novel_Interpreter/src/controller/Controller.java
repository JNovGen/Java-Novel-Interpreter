package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import novgen_model.Library;
import novgen_model.Load;
import novgen_model.Story;
import novgen_model.StoryNode;
import view.StoryEditorMainWindow;
import view.StoryProgressWindow;
import view.StoryRunWindow;

public class Controller implements ActionListener,ListSelectionListener{
	private StoryEditorMainWindow view;
	private Story story;
	private Library library;
	private StoryRunWindow rw;
	private StoryProgressWindow spw;
	
	public Controller(Story story,StoryEditorMainWindow view,Library l){
		this.story=story;
		library=l;
		this.view=view;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (view.getSearchButton()==arg0.getSource()){
			System.out.println("SEARCH");
			view.populateList();
			view.getMenuList().setSelectedIndices(story.searchNodes(view.getSearchNode().getText()));
		
		}
		if (view.getButtonRunStory()==arg0.getSource()){
			System.out.println("RUN STORY");
			story.setName(view.getTextStoryName().getText());
			story.setStartId(view.getTextStartWith().getText());
			story.setHeader(view.getTextHeader().getText());
			story.setFooter(view.getTextFooter().getText());
			story.setChapterHeader(view.getTextChapterHeader().getText());
			story.setChapterFooter(view.getTextChapterFooter().getText());
			try{
				int storyLength= Integer.valueOf(view.getTextStoryLenght().getText()).intValue();
				if (storyLength<3){
					storyLength=3;
					view.getTextStoryLenght().setText("3");
				}
				story.setLengthStory(storyLength);
			
			}catch (Exception e){
				story.setLengthStory(3);
				view.getTextStoryLenght().setText("3");
			}
			story.runStory(story.getStartId(), story.getLengthStory());
			rw=new StoryRunWindow(story);
			rw.setController(this);
		
		}
		if (view.getButtonResetPathChosen()==arg0.getSource()){
			System.out.println("RESET PATH CHOSEN");
			story.getListOfChoices().clear();
		}
		if (rw!=null){
			if (rw.getButtonShowProgress()==arg0.getSource()){
				System.out.println("SHOW PROGRESS WINDOW");
				StoryProgressWindow spw=new StoryProgressWindow(story);
				spw.setController(this);
			}
		}
		if (spw!=null){
			if (spw.getButtonRefresh()==arg0.getSource()){
				System.out.println("REFRESH PROGRESS");
				spw.setStory(story);
				spw.populateList();
			}
		}
		
		
		if (view.getOpenMenuItem()==arg0.getSource()){
			System.out.println("LOAD");
			File selectedFile=null;
	        JFileChooser fileChooser = new JFileChooser();
	        //fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
	        int result = fileChooser.showOpenDialog(null);
	        if (result == JFileChooser.APPROVE_OPTION) {
	        	selectedFile= fileChooser.getSelectedFile();
	        	System.out.println("Selected file: " + selectedFile.getAbsolutePath());
	        }
			story=Load.LoadStory(selectedFile.getAbsolutePath());
			view.setSavePath(selectedFile.getAbsolutePath());
			view.setTitle(selectedFile.getAbsolutePath());
			view.setStory(story);
			view.getTextStoryName().setText(story.getName());
			view.getTextStartWith().setText(story.getStartId());
			view.getTextStoryLenght().setText(String.valueOf(story.getLengthStory()));
			view.populateList();
			
			view.getTextIdNode().setText("");
			view.getTextContent().setText("");
			view.getTextCondition().setText("");
			view.getTextMemoryAddElt().setText("");
			view.getTextMemoryRemoveElt().setText("");
			view.getTextToNodes().setText("");
			view.getDlmToNodes().clear();
			view.getTextVariable().setText("");
			view.getCheckboxUnique().setSelected(false);
		}
		
		if (view.getExitMenuItem()==arg0.getSource()){
			System.out.println("EXIT");
			view.dispatchEvent(new WindowEvent(view, WindowEvent.WINDOW_CLOSING));
		}
		
		
		
		if (view.getButtonShowNode()==arg0.getSource()){
			System.out.println("SHOW NODE");
			if (view.getMenuList().getSelectedValue()!=null){
				StoryNode idNode=new StoryNode(view.getMenuList().getSelectedValue().toString());
				int indexNode=story.getNodes().indexOf(idNode);
				if (indexNode>=0){
					idNode=story.getNodes().get(indexNode);
					view.getTextIdNode().setText(idNode.getId());
					view.getTextContent().setText(idNode.getTextContent());
					view.getTextCondition().setText(idNode.getCondition());
					view.getTextMemoryAddElt().setText(idNode.getMemory_add());
					view.getTextMemoryRemoveElt().setText(idNode.getMemory_remove());
					view.getTextToNodes().setText(idNode.getTo_nodes_id());
					String[] strNodes=idNode.getTo_nodes_id().split(",");
					view.getDlmToNodes().clear();
					for (int i=0;i<strNodes.length;i++){
						view.getDlmToNodes().addElement(strNodes[i]);
					}
					view.getTextVariable().setText(idNode.getVar());
					view.getCheckboxUnique().setSelected(idNode.isUnique());
					
				}
			}
		}
		if (view.getStoryInfoMenuItem()==arg0.getSource()){
			System.out.println("SHOW STORY INFO");
			String author="---";
			String title="---";
			if (story.getName()!=null){
				title=story.getName();
			}
			if (story.getAuthor()!=null){
				author=story.getAuthor();
			}
			JOptionPane.showMessageDialog(null, "Title: "+title +"\n"+ "Author: "+author
					+"\n"+ "Number of nodes: "+story.getNodes().size());
			
		}

		if (view.getLibraryNewMenuItem()==arg0.getSource()){
			System.out.println("NEW LIBRARY");
			library= new Library();
			JOptionPane.showMessageDialog(null, "New library created");
		}
		if (view.getLibraryAddMenuItem()==arg0.getSource()){
			System.out.println("ADD STORY TO THE LIBRARY");
			if (!library.getStories().contains(story)){
				if (story.getName()!=null && story.getName().length()>0){
					library.getStories().add(story);
					JOptionPane.showMessageDialog(null, story.getName() + " added to the library");
				}else{
					JOptionPane.showMessageDialog(null, "The story must have a title");
				}
			}	
		}
		if (view.getLibraryInfoMenuItem()==arg0.getSource()){
			System.out.println("LIBRARY INFO");
			JOptionPane.showMessageDialog(null, "Number of stories in the library: "+library.getStories().size());	
			//JOptionPane.showMessageDialog(null, library.getStories().toArray());	
		}
		if (view.getLibraryRemoveMenuItem()==arg0.getSource()){
			System.out.println("REMOVE A STORY");
			if (library.getStories().size()>0){
				Story s =(Story) JOptionPane.showInputDialog(null, "Choose a story to remove", "Library",
			        JOptionPane.QUESTION_MESSAGE, null,library.getStories().toArray(), library.getStories().get(0));
				if (s!=null){
					library.getStories().remove(s);
					JOptionPane.showMessageDialog(null, story.getName() + " removed from the library");
			
				}
			}
		}
		if (view.getLibraryLoadStoryMenuItem()==arg0.getSource()){
			System.out.println("LOAD A STORY FROM THE LIBRARY");
			if (library.getStories().size()>0){
				Story s =(Story) JOptionPane.showInputDialog(null, "Choose a story to load:", "Library",
			        JOptionPane.QUESTION_MESSAGE, null,library.getStories().toArray(), library.getStories().get(0));
				
				story=s;
				view.setTitle(s.getName());
				view.setStory(story);
				view.getTextStoryName().setText(story.getName());
				view.getTextStartWith().setText(story.getStartId());
				view.getTextStoryLenght().setText(String.valueOf(story.getLengthStory()));
				view.populateList();
				
				view.getTextIdNode().setText("");
				view.getTextContent().setText("");
				view.getTextCondition().setText("");
				view.getTextMemoryAddElt().setText("");
				view.getTextMemoryRemoveElt().setText("");
				view.getTextToNodes().setText("");
				view.getDlmToNodes().clear();
				view.getTextVariable().setText("");
				view.getCheckboxUnique().setSelected(false);
				
				JOptionPane.showMessageDialog(null, story.getName() + " loaded from the library");
			}else{
				JOptionPane.showMessageDialog(null, "The library is empty");
			}
		}
		if (view.getLibraryOpenMenuItem()==arg0.getSource()){
			System.out.println("LOAD LIBRARY");
			File selectedFile=null;
	        JFileChooser fileChooser = new JFileChooser();
	        //fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
	        int result = fileChooser.showOpenDialog(null);
	        if (result == JFileChooser.APPROVE_OPTION) {
	        	selectedFile= fileChooser.getSelectedFile();
	        	System.out.println("Selected file: " + selectedFile.getAbsolutePath());
	        }
			library=Load.LoadLibrary(selectedFile.getAbsolutePath());
			JOptionPane.showMessageDialog(null, "Library loaded");
		}
		
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		if (view.getMenuList()==arg0.getSource()){
			if (view.getMenuList().getSelectedValue()!=null){
				view.getTextStartWith().setText(view.getMenuList().getSelectedValue().toString());
			}
		}
		
	}

	public Story getStory() {
		return story;
	}

	public void setStory(Story story) {
		this.story = story;
	}
	
}
