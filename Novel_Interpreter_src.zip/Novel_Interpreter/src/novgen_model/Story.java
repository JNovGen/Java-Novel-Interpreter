package novgen_model;
import java.util.ArrayList;
import java.util.Random;


public class Story {
	private String name;
	private String author;
	private ArrayList<StoryNode> nodes;
	private ArrayList<String> listOfChoices;
	private String startId;
	private int lengthStory;
	private String strStory;
	private StoryMemory memory;
	private Random randomNumber;
	private String header;
	private String footer;
	private String chapterHeader;
	private String chapterFooter;
	
	public Story(){
		
		strStory=new String();
		nodes=new ArrayList<StoryNode>();
		listOfChoices=new ArrayList<String>();
		randomNumber= new Random();
		name="";
		author="";
		
	}
	public int[] searchNodes(String txt){
		int[] indices=null;
		ArrayList<Integer> indiceList=new ArrayList<Integer>();
		for (int i=0;i<nodes.size();i++){
			int index=nodes.get(i).getId().indexOf(txt);
			if (index>=0){
				indiceList.add(i);
			}
		}
		indices=new int[indiceList.size()];
		for (int i=0;i<indiceList.size();i++){
			indices[i]=indiceList.get(i);
		}
		return indices;
	}
	public ArrayList<StoryNode> getNodes() {
		return nodes;
	}

	public void setNodes(ArrayList<StoryNode> nodes) {
		this.nodes = nodes;
	}
	
	public boolean addStoryNode(StoryNode sn){
		boolean added=false;
		if (!nodes.contains(sn)){
			nodes.add(sn);
			added=true;
		}
		return added;
	}
	
	public void runStory(String id,int storyLength){
		StoryNode tempNode= new StoryNode(id);
		memory=new StoryMemory();
		int indexEntry=nodes.indexOf(tempNode);
		int index=0;
		if (indexEntry>=0){
			StoryNode startNode= nodes.get(indexEntry);
			if (startNode.getMemory_add().length()>0){
				memory.addMemory(startNode.getMemory_add());
			}
			
			StoryNode nextNode =startNode.runAndGetNextNode(nodes,listOfChoices,index,memory);
			
			//System.out.println(memory.getMemory().toString());
			ArrayList<StoryNode> nodesStory= new ArrayList<StoryNode>();
			nodesStory.add(nextNode);
			for (int i=0;i<storyLength-2;i++){
				index++;
				StoryNode sn=null;
				try{
					sn=nodesStory.get(i).runAndGetNextNode(nodes,listOfChoices,index,memory);
					
				}catch(Exception e){
					System.out.println("ERROR: cannot get a story node");
				}
				if (sn!=null){
					nodesStory.add(sn);
				}else{
					break;
				}
			}
		}
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getListOfChoices() {
		return listOfChoices;
	}

	public void setListOfChoices(ArrayList<String> listOfChoices) {
		this.listOfChoices = listOfChoices;
	}

	public String getStartId() {
		return startId;
	}

	public void setStartId(String startId) {
		this.startId = startId;
	}

	public int getLengthStory() {
		return lengthStory;
	}

	public void setLengthStory(int lengthStory) {
		this.lengthStory = lengthStory;
	}

	public String getStrStory() {
		int nbChapter=0;
		String str="";
		StoryNode startNode=new StoryNode(this.startId);
		int indexStartNode= this.getNodes().indexOf(startNode);
		if (indexStartNode>=0){
			startNode=getNodes().get(indexStartNode);
			//--random choose for text variety
			String buffer=startNode.getTextContent();
			if (startNode.getTextContent().indexOf("#")>=0){
				String syn[]= startNode.getTextContent().split("#");
				int r=randomNumber.nextInt(syn.length);
				startNode.setTextContent(syn[r]);
				
			}
			if (startNode.getTextContent().length()>0) startNode.setTextContent(header+startNode.getTextContent()+footer);
			
			memory.updateMemory(0);
			str=startNode.replaceVarInText(startNode.getTextContent(),this.memory)+"";
			if (str.indexOf("<chapter>")>=0){
				nbChapter++;
				str=str.replaceFirst("<chapter>", footer+"\n\n"+chapterHeader+" - "+nbChapter+" - "+chapterFooter+header+"\n\n");
			}
			startNode.setTextContent(buffer);
			for (int i=0;i<listOfChoices.size();i++){
				StoryNode tempNode=new StoryNode(listOfChoices.get(i));
				int index= this.getNodes().indexOf(tempNode);
				if (index>=0){
					StoryNode sn= this.getNodes().get(index);
					buffer=sn.getTextContent();
					if (sn.getTextContent().indexOf("#")>=0){
						String syn[]= sn.getTextContent().split("#");
						int r=randomNumber.nextInt(syn.length);
						sn.setTextContent(syn[r]);
					}
					if (sn.getTextContent().length()>0) sn.setTextContent(header+sn.getTextContent()+footer);
					
					memory.updateMemory(i);
					String replaced=sn.replaceVarInText(sn.getTextContent(), this.memory);
					str=str+replaced+"";
					System.out.println(sn.getId());
					System.out.println("before:"+sn.getTextContent());
					System.out.println("after:"+replaced);
					System.out.println("---");
					if (str.indexOf("<chapter>")>=0){
						nbChapter++;
						str=str.replaceFirst("<chapter>", footer+"\n\n"+chapterHeader+" - "+nbChapter+" - "+chapterFooter+header+"\n\n");
					}
					sn.setTextContent(buffer);
					
				}
			}
		}
		
		return str;
	}

	public void setStrStory(String strStory) {
		this.strStory = strStory;
	}
	
	public StoryMemory getMemory() {
		return memory;
	}

	public void setMemory(StoryMemory memory) {
		this.memory = memory;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public boolean equals(Object o){
		boolean result= false;
		Story s= (Story) o;
		if (this.getName().equals(s.getName())){
			if (this.getAuthor().equals(s.getAuthor())){
				result =true;
			}
		}
		return result;
	}
	public String toString(){
		return this.name+ " - "+ this.author;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getFooter() {
		return footer;
	}
	public void setFooter(String footer) {
		this.footer = footer;
	}
	public String getChapterHeader() {
		return chapterHeader;
	}
	public void setChapterHeader(String chapterHeader) {
		this.chapterHeader = chapterHeader;
	}
	public String getChapterFooter() {
		return chapterFooter;
	}
	public void setChapterFooter(String chapterFooter) {
		this.chapterFooter = chapterFooter;
	}
	
}
