package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class FrameInfo extends JFrame{
	private static final long serialVersionUID = 515480509755911594L;

	public FrameInfo(){
		super.setTitle("Welcome");
		super.setSize(460,300);
		super.setLayout(new BorderLayout());
		super.add(new JLabel(new ImageIcon("img.png")),BorderLayout.CENTER);
		super.add(new JLabel(""),BorderLayout.NORTH);
		super.add(new JLabel("Java Novel Interpreter Version 1.0, http://greenorb.free.fr"),BorderLayout.SOUTH);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		super.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		super.setVisible(true);
	}

}
