package view;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import novgen_model.Story;
import controller.Controller;

public class StoryRunWindow extends JFrame{

	private static final long serialVersionUID = -1510473049774391468L;
	private Story story;
	private JButton buttonShowProgress;
	
	public StoryRunWindow(Story story){
		this.story=story;
		this.setSize(800, 600);
		this.setTitle("Generated story");
		JLabel labelTitleStory=new JLabel("title: "+story.getName());
		JTextArea jStory = new JTextArea(story.getStrStory());
		jStory.setLineWrap(true);
		jStory.setWrapStyleWord(true);
		JScrollPane jscrollpane=new JScrollPane(jStory);
		JPanel jpanel=new JPanel();
		jpanel.setLayout(new BorderLayout());
		
		buttonShowProgress=new JButton("Show progress");
		
		JPanel panelNorth = new JPanel();
		panelNorth.add(buttonShowProgress);
		//panelNorth.add(labelTitleStory);
		
		jpanel.add(panelNorth,BorderLayout.NORTH);
		jpanel.add(jscrollpane,BorderLayout.CENTER);
		this.add(jpanel);
		this.setVisible(true);
	}
	
	public void setController(Controller c){
		buttonShowProgress.addActionListener(c);
	}

	public JButton getButtonShowProgress() {
		return buttonShowProgress;
	}

	public void setButtonShowProgress(JButton buttonShowProgress) {
		this.buttonShowProgress = buttonShowProgress;
	}

	
}
