package view;
import java.awt.Color;
import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ListRenderer extends JLabel implements ListCellRenderer<Object> {

	private static final long serialVersionUID = 5505885331921156661L;
	ImageIcon iconBlue;
    ImageIcon iconYellow;
    ImageIcon iconChoix;
    Color selectCouleur = Color.BLUE;

    public ListRenderer(boolean isAnextNodeType){
  
      if (isAnextNodeType){
    	  iconYellow  = new ImageIcon("yellow.png");
    	  iconChoix= iconYellow;
      }
      else{
    	  iconBlue  = new ImageIcon("blue.png");
    	  iconChoix=iconBlue;
      }
    }

    public Component getListCellRendererComponent(
      JList<?> list,
      Object value,            // valeur à afficher
      int index,
      boolean isSelected,      // l'item est-il s�lectionn�
      boolean cellHasFocus)    // La liste a-t-elle le focus
    {
    	for (int i=0;i<list.getModel().getSize();i++){
    		//competence =(Competence) list.getModel().getElementAt(i);
    		//if (competence.isTech()){
    			//setIcon(iconTech);
    		//}
    		//else
    		{
    			//setIcon(iconChoix);
    		}
   		}
    	String s=null;
    	if (value!=null){
    		s = value.toString();
    		if (!s.equals("")){
    			setIcon(iconChoix);
    			setText(s);
    		}else{
    			setIcon(null);
    		}
    	}else{
    		setIcon(null);
    	}
        
        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(selectCouleur);
            //setText(s+"  "+index);
            setText(s);
            //setIcon(selectIcon);
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
            setText(s);       
            //setIcon(icon);
          }
          setEnabled(list.isEnabled());
          setFont(list.getFont());
          setOpaque(true);
          
          return this;
    }

}