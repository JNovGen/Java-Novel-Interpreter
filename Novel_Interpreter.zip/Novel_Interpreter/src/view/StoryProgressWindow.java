package view;

import java.awt.BorderLayout;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;

import novgen_model.Story;
import novgen_model.StoryNode;
import controller.Controller;

public class StoryProgressWindow extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8187696293364167666L;
	private JList<String> menuList;
	private JScrollPane menuScrollPane;
	private ListRenderer rendererListNodes=new ListRenderer(false);
	private DefaultListModel<String> dlm;
	private JButton buttonRefresh;
	private Story story;
	public StoryProgressWindow(Story story){
		this.story=story;
		this.setTitle("Path chosen");
		this.setSize(400, 600);
		JPanel panel=new JPanel();
		panel.setLayout(new BorderLayout());
		buttonRefresh=new JButton("Refresh progress");
		
		JPanel panelNorth=new JPanel();
		panelNorth.add(buttonRefresh);

		
		menuList = new JList<String>();
		menuList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		menuList.setLayoutOrientation(JList.VERTICAL);
		menuList.setCellRenderer((ListCellRenderer) rendererListNodes.getListCellRendererComponent(menuList,dlm,1,true,false));
		menuScrollPane = new JScrollPane(menuList);
		
		panel.add(panelNorth,BorderLayout.NORTH);
		panel.add(menuScrollPane,BorderLayout.CENTER);
		
		populateList();
		this.add(panel);
		this.setVisible(true);
	}
	public void populateList(){
		dlm= new DefaultListModel<String>();
		dlm.addElement(story.getStartId());
		for (int i=0;i<story.getListOfChoices().size()-1;i++){
			dlm.addElement(story.getListOfChoices().get(i)+" /Memory: "+story.getMemory().memToString(story.getMemory().getGlobalMemory().get(i)));
			//System.out.println(story.getListOfChoices().get(i));
		}
		System.out.println(story.getListOfChoices().size()-1);
		int indexEntry=story.getListOfChoices().size()-2;
		if (indexEntry<0) indexEntry=0;
		StoryNode sn=new StoryNode(story.getListOfChoices().get(indexEntry));
		indexEntry= story.getNodes().indexOf(sn);
		System.out.println(indexEntry);
		
		StoryNode endNode= story.getNodes().get(indexEntry).getNextNode();
		if (endNode!=null){
			System.out.println("added");
			dlm.addElement(endNode.getId()+" /Memory: "+story.getMemory().memToString(story.getMemory().getGlobalMemory().get(story.getListOfChoices().size()-1)));
		}else{
			System.out.println("null");
		}
		menuList.setModel(dlm);
	}
	
	public void setController(Controller c){
		buttonRefresh.addActionListener(c);
	}
	public JButton getButtonRefresh() {
		return buttonRefresh;
	}

	public void setButtonRefresh(JButton buttonRefresh) {
		this.buttonRefresh = buttonRefresh;
	}
	public Story getStory() {
		return story;
	}
	public void setStory(Story story) {
		this.story = story;
	}
	
}
