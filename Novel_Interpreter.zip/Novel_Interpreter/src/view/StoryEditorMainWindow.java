package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;

import novgen_model.Story;
import controller.Controller;

public class StoryEditorMainWindow extends JFrame{

	private static final long serialVersionUID = 5359529532488146110L;
	private JPanel bottomPanel=new JPanel();
	private JList<String> menuList;
	private JScrollPane menuScrollPane;
	private JList<String> listToNodes;
	private JScrollPane listToNodesScrollPane;
	private JButton buttonLoad;
	
	private JPanel topPanel=new JPanel();
	private JPanel centerPanel=new JPanel();
	private JTextArea textIdNode;
	private JTextArea textContent;
	private JTextArea textMemoryAddElt;
	private JTextArea textMemoryRemoveElt;
	private JTextArea textCondition;
	private JTextArea textVariable;
	private JCheckBox checkboxUnique;
	private JTextArea textToNodes;
	private ListRenderer rendererListNodes=new ListRenderer(false);
	private DefaultListModel<String> dlm;
	private ListRenderer rendererListToNodes=new ListRenderer(true);
	private DefaultListModel<String> dlmToNodes;
	private JButton buttonShowNode;
	private JTextArea textSotryLenght;
	private JTextArea textStartWith;
	
	private JTextArea textHeader;
	private JTextArea textFooter;
	private JTextArea textChapterHeader;
	private JTextArea textChapterFooter;
	
	private JButton buttonRunStory;
	private JTextArea textStoryName;
	private JButton buttonResetPathChosen;
	private JTextArea searchNode;
	private JButton searchButton;
	private JMenuItem openMenuItem;
	private String savePath;
	private JMenuItem exitMenuItem;
	private JMenuItem storyInfoMenuItem;
	private JMenuItem libraryNewMenuItem;
	private JMenuItem libraryOpenMenuItem;
	private JMenuItem libraryInfoMenuItem;
	private JMenuItem libraryAddMenuItem;
	private JMenuItem libraryRemoveMenuItem;
	private JMenuItem libraryLoadStoryMenuItem;
	private JMenuItem ViewMenuItem;
	public JMenuItem getLibraryNewMenuItem() {
		return libraryNewMenuItem;
	}

	public void setLibraryNewMenuItem(JMenuItem libraryNewMenuItem) {
		this.libraryNewMenuItem = libraryNewMenuItem;
	}

	public JMenuItem getLibraryOpenMenuItem() {
		return libraryOpenMenuItem;
	}

	public void setLibraryOpenMenuItem(JMenuItem libraryOpenMenuItem) {
		this.libraryOpenMenuItem = libraryOpenMenuItem;
	}

	public JMenuItem getLibraryInfoMenuItem() {
		return libraryInfoMenuItem;
	}

	public void setLibraryInfoMenuItem(JMenuItem libraryInfoMenuItem) {
		this.libraryInfoMenuItem = libraryInfoMenuItem;
	}

	public JMenuItem getLibraryAddMenuItem() {
		return libraryAddMenuItem;
	}

	public void setLibraryAddMenuItem(JMenuItem libraryAddMenuItem) {
		this.libraryAddMenuItem = libraryAddMenuItem;
	}

	public JMenuItem getLibraryRemoveMenuItem() {
		return libraryRemoveMenuItem;
	}

	public void setLibraryRemoveMenuItem(JMenuItem libraryRemoveMenuItem) {
		this.libraryRemoveMenuItem = libraryRemoveMenuItem;
	}

	private Story story;
	private Controller controller;

	
	public StoryEditorMainWindow(Story story){
		this.story=story;
		this.setTitle("Story editor");
		this.setSize(800, 600);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		super.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		searchButton=new JButton("Search");
		searchNode=new JTextArea();
		searchNode.setPreferredSize(new Dimension(160,24));
		JLabel labelStartWith= new JLabel("Start with:");
		JLabel labelStoryLenght= new JLabel("Length of story:");
		textStartWith= new JTextArea("story node name");
		//textStartWith.setPreferredSize(new Dimension(150,24));
		this.textSotryLenght=new JTextArea("100");
		Border border = BorderFactory.createLineBorder(Color.GRAY);

		this.textHeader=new JTextArea("");
		textHeader.setBorder(BorderFactory.createCompoundBorder(border, BorderFactory.createEmptyBorder(4, 4, 4, 4)));
		this.textFooter=new JTextArea("");
		textFooter.setBorder(BorderFactory.createCompoundBorder(border, BorderFactory.createEmptyBorder(4, 4, 4, 4)));
		this.textChapterHeader=new JTextArea("");
		textChapterHeader.setBorder(BorderFactory.createCompoundBorder(border, BorderFactory.createEmptyBorder(4, 4, 4, 4)));
		this.textChapterFooter=new JTextArea("");
		textChapterFooter.setBorder(BorderFactory.createCompoundBorder(border, BorderFactory.createEmptyBorder(4, 4, 4, 4)));
		buttonRunStory=new JButton("Run story");
		buttonResetPathChosen=new JButton("Reset path chosen");
		this.buttonShowNode= new JButton("Show node");
		bottomPanel.setLayout(new BorderLayout());
		JPanel northRsPanel=new JPanel();
		northRsPanel.setLayout(new FlowLayout());

		JPanel jpStartWith=new JPanel();
		jpStartWith.setLayout(new BorderLayout());
		JScrollPane jscrollp=new JScrollPane(textStartWith);
		jpStartWith.add(jscrollp,BorderLayout.CENTER);
		jpStartWith.setPreferredSize(new Dimension(150,40));
		northRsPanel.add(labelStartWith);
		northRsPanel.add(jpStartWith);
		northRsPanel.add(labelStoryLenght);
		northRsPanel.add(textSotryLenght);
		JPanel centerRsPanel=new JPanel();
		centerRsPanel.setLayout(new GridLayout(4,2));
		centerRsPanel.add(new JLabel("Node header:"));
		centerRsPanel.add(textHeader);
		centerRsPanel.add(new JLabel("Node footer:"));
		centerRsPanel.add(textFooter);
		centerRsPanel.add(new JLabel("Node chapter header:"));
		centerRsPanel.add(textChapterHeader);
		centerRsPanel.add(new JLabel("Node chapter footer:"));
		centerRsPanel.add(textChapterFooter);
		JPanel southRsPanel=new JPanel();
		southRsPanel.setLayout(new FlowLayout());
		southRsPanel.add(buttonRunStory);
		southRsPanel.add(buttonResetPathChosen);
		bottomPanel.add(northRsPanel,BorderLayout.NORTH);
		bottomPanel.add(centerRsPanel,BorderLayout.CENTER);
		bottomPanel.add(southRsPanel,BorderLayout.SOUTH);
		this.setLayout(new BorderLayout());
		//this.add(bottomPanel,BorderLayout.SOUTH);
		
		menuList = new JList<String>();
		menuList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		menuList.setLayoutOrientation(JList.VERTICAL);
		menuList.setCellRenderer((ListCellRenderer) rendererListNodes.getListCellRendererComponent(menuList,dlm,1,true,false));
		menuScrollPane = new JScrollPane(menuList);
		populateList();
		
		listToNodes = new JList<String>();
		listToNodes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listToNodes.setLayoutOrientation(JList.VERTICAL);
		listToNodes.setCellRenderer((ListCellRenderer) rendererListToNodes.getListCellRendererComponent(menuList,dlmToNodes,1,true,false));
		listToNodesScrollPane = new JScrollPane(listToNodes);
		dlmToNodes= new DefaultListModel<String>();
		listToNodes.setModel(dlmToNodes);
		JPanel menuListPanel = new JPanel();
		menuListPanel.setLayout(new BorderLayout());
		JPanel searchPanel= new JPanel();
		searchPanel.add(searchNode);
		searchPanel.add(searchButton);
		menuListPanel.setPreferredSize(new Dimension(400,600));
		menuListPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		menuListPanel.add(searchPanel,BorderLayout.NORTH);
		menuListPanel.add(menuScrollPane,BorderLayout.CENTER);
		
		
		this.add(menuListPanel,BorderLayout.WEST);
		
		JLabel labelStoryName= new JLabel("Story name:");
		textStoryName= new JTextArea("");
		textStoryName.setPreferredSize(new Dimension(100,24));
		buttonLoad=new JButton("Load");
		topPanel.setLayout(new FlowLayout());
		topPanel.add(labelStoryName);
		topPanel.add(textStoryName);
		topPanel.add(buttonLoad);
		
		//this.add(topPanel,BorderLayout.NORTH);
		
		JLabel labelIdNode = new JLabel("Story node name:");
		textIdNode = new JTextArea("");
		JScrollPane jp=new JScrollPane(textIdNode);
		JPanel jpIdnode=new JPanel();
		jpIdnode.setLayout(new BorderLayout());
		jpIdnode.add(labelIdNode,BorderLayout.NORTH);jpIdnode.add(jp,BorderLayout.CENTER);
		
		JLabel labelTextContent= new JLabel("Description:");
		textContent = new JTextArea("");
		jp=new JScrollPane(textContent);
		JPanel jpTextContent=new JPanel();
		jpTextContent.setLayout(new BorderLayout());
		jpTextContent.add(labelTextContent,BorderLayout.NORTH);jpTextContent.add(jp,BorderLayout.CENTER);
		
		JLabel labelMemoryAddElt= new JLabel("Memory add element:");
		textMemoryAddElt = new JTextArea("");
		jp=new JScrollPane(textMemoryAddElt);
		JPanel jpTextMemoryAddElt=new JPanel();
		jpTextMemoryAddElt.setLayout(new BorderLayout());
		jpTextMemoryAddElt.add(labelMemoryAddElt,BorderLayout.NORTH);jpTextMemoryAddElt.add(jp,BorderLayout.CENTER);
		
		JLabel labelMemoryRemoveElt= new JLabel("Memory remove element:");
		textMemoryRemoveElt = new JTextArea("");
		jp=new JScrollPane(textMemoryRemoveElt);
		JPanel jpTextMemoryRemoveElt=new JPanel();
		jpTextMemoryRemoveElt.setLayout(new BorderLayout());
		jpTextMemoryRemoveElt.add(labelMemoryRemoveElt,BorderLayout.NORTH);jpTextMemoryRemoveElt.add(jp,BorderLayout.CENTER);
		
		JLabel labelCondition= new JLabel("Condition:");
		textCondition = new JTextArea("");
		jp=new JScrollPane(textCondition);
		JPanel jpTextCondition=new JPanel();
		jpTextCondition.setLayout(new BorderLayout());
		jpTextCondition.add(labelCondition,BorderLayout.NORTH);jpTextCondition.add(jp,BorderLayout.CENTER);
		
		checkboxUnique=new JCheckBox("Unique");
		
		JLabel labelVariable=new JLabel("Variable name:");
		textVariable = new JTextArea("");
		jp=new JScrollPane(textVariable);
		JPanel jpTextVariable=new JPanel();
		jpTextVariable.setLayout(new BorderLayout());
		jpTextVariable.add(labelVariable,BorderLayout.NORTH);jpTextVariable.add(jp,BorderLayout.CENTER);
		
		JLabel labelToNodes=new JLabel("Next story nodes");
		JPanel southPanel=new JPanel();
		textToNodes = new JTextArea("");
		textToNodes.setPreferredSize(new Dimension(100,24));
		southPanel.add(labelToNodes);
		JPanel jpTextToNodes=new JPanel();
		
		jpTextToNodes.setLayout(new BorderLayout());
		jpTextToNodes.add(southPanel,BorderLayout.SOUTH);jpTextToNodes.add(listToNodesScrollPane,BorderLayout.CENTER);
		
		JTabbedPane onglets = new JTabbedPane();
		JPanel panelNodeStoryDesc= new JPanel();
		panelNodeStoryDesc.setLayout(new GridLayout(4,1));
		panelNodeStoryDesc.add(jpIdnode);
		panelNodeStoryDesc.add(jpTextContent);
		panelNodeStoryDesc.add(jpTextVariable);
		panelNodeStoryDesc.add(jpTextToNodes);
		onglets.addTab("Story node description", null, panelNodeStoryDesc, null);
		centerPanel.setLayout(new BorderLayout());
		//onglets.addTab("Next story nodes", null, jpTextToNodes, null);
		JPanel panelCondition= new JPanel();
		panelCondition.setLayout(new GridLayout(2,1));
		panelCondition.add(jpTextCondition);
		panelCondition.add(checkboxUnique);
		onglets.addTab("Condition", null, panelCondition, null);
		JPanel panelMemory= new JPanel();
		panelMemory.setLayout(new GridLayout(2,1));
		panelMemory.add(jpTextMemoryAddElt);
		panelMemory.add(jpTextMemoryRemoveElt);
		onglets.addTab("Memory", null, panelMemory, null);
		onglets.addTab("Run story", null, bottomPanel, null);
		
		/*
		centerPanel.setLayout(new GridLayout(5,2));
		centerPanel.add(jpIdnode);
		centerPanel.add(jpTextContent);
		centerPanel.add(jpTextMemoryAddElt);
		centerPanel.add(jpTextMemoryRemoveElt);
		centerPanel.add(jpTextCondition);
		centerPanel.add(checkboxUnique);
		centerPanel.add(jpTextVariable);
		centerPanel.add(jpTextToNodes);
		*/
		centerPanel.add(onglets,BorderLayout.CENTER);
		JPanel pButton1=new JPanel();
		pButton1.add(buttonShowNode);
		menuListPanel.add(pButton1,BorderLayout.SOUTH);
		this.add(centerPanel,BorderLayout.CENTER);
		openMenuItem = new JMenuItem("Open a story");
	    exitMenuItem = new JMenuItem("Exit");
	    JMenu fileMenu = new JMenu("File");
	    JMenu storyMenu = new JMenu("Story");
	 
		storyInfoMenuItem = new JMenuItem("Story Information");
	    
	   
	    fileMenu.addSeparator();
	    fileMenu.add(openMenuItem);
	    fileMenu.addSeparator();


	    
	    fileMenu.addSeparator();
	    fileMenu.add(exitMenuItem); 
	    storyMenu.add(storyInfoMenuItem);
	    
	
	    JMenuBar menuBar = new JMenuBar();
	    menuBar.add(fileMenu);
	    menuBar.add(storyMenu);

	    this.setJMenuBar(menuBar);
		this.setVisible(true);
	}

	public JMenuItem getExitMenuItem() {
		return exitMenuItem;
	}

	public void setExitMenuItem(JMenuItem exitMenuItem) {
		this.exitMenuItem = exitMenuItem;
	}

	public void populateList(){
		dlm= new DefaultListModel<String>();
		for (int i=0;i<story.getNodes().size();i++){
			dlm.addElement(story.getNodes().get(i).getId());
		}
		menuList.setModel(dlm);
	}

	public JList<String> getMenuList() {
		return menuList;
	}

	public void setMenuList(JList<String> menuList) {
		this.menuList = menuList;
	}

	public JTextArea getTextIdNode() {
		return textIdNode;
	}

	public void setTextIdNode(JTextArea textIdNode) {
		this.textIdNode = textIdNode;
	}

	public JTextArea getTextContent() {
		return textContent;
	}

	public void setTextContent(JTextArea textContent) {
		this.textContent = textContent;
	}

	public JTextArea getTextMemoryAddElt() {
		return textMemoryAddElt;
	}

	public void setTextMemoryAddElt(JTextArea textMemoryAddElt) {
		this.textMemoryAddElt = textMemoryAddElt;
	}

	public JTextArea getTextMemoryRemoveElt() {
		return textMemoryRemoveElt;
	}

	public void setTextMemoryRemoveElt(JTextArea textMemoryRemoveElt) {
		this.textMemoryRemoveElt = textMemoryRemoveElt;
	}

	public JTextArea getTextCondition() {
		return textCondition;
	}

	public void setTextCondition(JTextArea textCondition) {
		this.textCondition = textCondition;
	}

	public JTextArea getTextVariable() {
		return textVariable;
	}

	public void setTextVariable(JTextArea textVariable) {
		this.textVariable = textVariable;
	}

	public JCheckBox getCheckboxUnique() {
		return checkboxUnique;
	}

	public void setCheckboxUnique(JCheckBox checkboxUnique) {
		this.checkboxUnique = checkboxUnique;
	}

	public JTextArea getTextToNodes() {
		return textToNodes;
	}

	public void setTextToNodes(JTextArea textToNodes) {
		this.textToNodes = textToNodes;
	}

	public DefaultListModel<String> getDlm() {
		return dlm;
	}

	public void setDlm(DefaultListModel<String> dlm) {
		this.dlm = dlm;
	}

	public Controller getController() {
		return controller;
	}

	public void setController(Controller controller) {
		this.controller = controller;

		menuList.addListSelectionListener(controller);
		listToNodes.addListSelectionListener(controller);

		this.buttonShowNode.addActionListener(controller);
		this.buttonRunStory.addActionListener(controller);

		this.buttonLoad.addActionListener(controller);

		openMenuItem.addActionListener(controller);

		exitMenuItem.addActionListener(controller);
		this.buttonResetPathChosen.addActionListener(controller);
		this.searchButton.addActionListener(controller);
		storyInfoMenuItem.addActionListener(controller);

	}

	

	public String getSavePath() {
		return savePath;
	}

	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}

	public JMenuItem getOpenMenuItem() {
		return openMenuItem;
	}

	public void setOpenMenuItem(JMenuItem openMenuItem) {
		this.openMenuItem = openMenuItem;
	}

	public JList<String> getListToNodes() {
		return listToNodes;
	}

	public void setListToNodes(JList<String> listToNodes) {
		this.listToNodes = listToNodes;
	}

	public DefaultListModel<String> getDlmToNodes() {
		return dlmToNodes;
	}

	public void setDlmToNodes(DefaultListModel<String> dlmToNodes) {
		this.dlmToNodes = dlmToNodes;
	}

	

	public JButton getButtonShowNode() {
		return buttonShowNode;
	}

	public void setButtonShowNode(JButton buttonShowNode) {
		this.buttonShowNode = buttonShowNode;
	}

	public JTextArea getTextStoryLenght() {
		return textSotryLenght;
	}

	public void setTextSotryLenght(JTextArea textSotryLenght) {
		this.textSotryLenght = textSotryLenght;
	}

	public JTextArea getTextStartWith() {
		return textStartWith;
	}

	public void setTextStartWith(JTextArea textStartWith) {
		this.textStartWith = textStartWith;
	}

	public JButton getButtonRunStory() {
		return buttonRunStory;
	}

	public void setButtonRunStory(JButton buttonRunStory) {
		this.buttonRunStory = buttonRunStory;
	}

	public Story getStory() {
		return story;
	}

	public void setStory(Story story) {
		this.story = story;
	}

	public JTextArea getTextStoryName() {
		return textStoryName;
	}

	public void setTextStoryName(JTextArea textStoryName) {
		this.textStoryName = textStoryName;
	}

	
	public JButton getButtonLoad() {
		return buttonLoad;
	}

	public void setButtonLoad(JButton buttonLoad) {
		this.buttonLoad = buttonLoad;
	}

	public JButton getButtonResetPathChosen() {
		return buttonResetPathChosen;
	}

	public void setButtonResetPathChosen(JButton buttonResetPathChosen) {
		this.buttonResetPathChosen = buttonResetPathChosen;
	}

	public JTextArea getSearchNode() {
		return searchNode;
	}

	public void setSearchNode(JTextArea searchNode) {
		this.searchNode = searchNode;
	}

	public JButton getSearchButton() {
		return searchButton;
	}

	public void setSearchButton(JButton searchButton) {
		this.searchButton = searchButton;
	}



	public JMenuItem getStoryInfoMenuItem() {
		return storyInfoMenuItem;
	}

	public void setStoryInfoMenuItem(JMenuItem storyInfoMenuItem) {
		this.storyInfoMenuItem = storyInfoMenuItem;
	}

	

	public JMenuItem getLibraryLoadStoryMenuItem() {
		return libraryLoadStoryMenuItem;
	}

	public void setLibraryLoadStoryMenuItem(JMenuItem libraryLoadStoryMenuItem) {
		this.libraryLoadStoryMenuItem = libraryLoadStoryMenuItem;
	}

	public JMenuItem getViewMenuItem() {
		return ViewMenuItem;
	}

	public void setViewMenuItem(JMenuItem viewMenuItem) {
		ViewMenuItem = viewMenuItem;
	}


	public JTextArea getTextHeader() {
		return textHeader;
	}

	public void setTextHeader(JTextArea textHeader) {
		this.textHeader = textHeader;
	}

	public JTextArea getTextFooter() {
		return textFooter;
	}

	public void setTextFooter(JTextArea textFooter) {
		this.textFooter = textFooter;
	}

	public JTextArea getTextChapterHeader() {
		return textChapterHeader;
	}

	public void setTextChapterHeader(JTextArea textChapterHeader) {
		this.textChapterHeader = textChapterHeader;
	}

	public JTextArea getTextChapterFooter() {
		return textChapterFooter;
	}

	public void setTextChapterFooter(JTextArea textChapterFooter) {
		this.textChapterFooter = textChapterFooter;
	}


}
