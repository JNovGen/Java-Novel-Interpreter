package novgen_model;
import java.util.ArrayList;
import java.util.Random;


public class StoryNode {
	private String id;
	private String memory_add;
	private String memory_remove;
	private String condition;
	private String to_nodes_id;
	private boolean unique;
	private String var;
	private String textContent;
	private Random randomNumber;
	private StoryNode nextNode;

	
	
	public StoryNode(String id){
		this.id=id;
		randomNumber= new Random();
		
	}
	
	public StoryNode(String id,String textContent,String memory_add,String memory_remove,String condition,String to_nodes_id,boolean unique,String var){
		this(id);
		this.textContent=textContent;
		this.memory_add=memory_add;
		this.memory_remove=memory_remove;
		this.condition=condition;
		this.to_nodes_id=to_nodes_id;
		this.unique=unique;
		this.var=var;
	}
	public String toString(){
		String s="";
		s=s+"id:"+id+"\n";
		s=s+"textContent:"+textContent+"\n";
		s=s+"memory_add:"+memory_add+"\n";
		s=s+"memory_remove:"+memory_remove+"\n";
		s=s+"condition:"+condition+"\n";
		s=s+"to_nodes_id:"+to_nodes_id+"\n";
		s=s+"unique:"+unique+"\n";
		s=s+"var:"+var+"\n";
		return s;
	}
	
	public boolean equals(Object o){
		boolean result=false;
		StoryNode sn= (StoryNode) o;
		if (this.getId().equals(sn.getId())){
			result=true;
		}
		return result;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMemory_add() {
		return memory_add;
	}

	public void setMemory_add(String memory_add) {
		this.memory_add = memory_add;
	}

	public String getMemory_remove() {
		return memory_remove;
	}

	public void setMemory_remove(String memory_remove) {
		this.memory_remove = memory_remove;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getTo_nodes_id() {
		return to_nodes_id;
	}

	public void setTo_nodes_id(String to_nodes_id) {
		this.to_nodes_id = to_nodes_id;
	}

	public boolean isUnique() {
		return unique;
	}

	public void setUnique(boolean unique) {
		this.unique = unique;
	}

	public String getVar() {
		return var;
	}

	public void setVar(String var) {
		this.var = var;
	}

	public String getTextContent() {
		return textContent;
	}

	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}
	
	public StoryNode runAndGetNextNode(ArrayList<StoryNode> nodes,ArrayList<String> listOfChoices,int index,StoryMemory mem){
		StoryNode sn=null;
		if (this.var.length()>0){
			/*
			String[] s=this.var.split(",");
			for (int i=0;i<s.length;i++){
				String content= this.getTextContent();
				
				if (content.indexOf(s[i])>=0){
					
					String replacewith = mem.getValueFromMemory(s[i]);
					String search=s[i];
					content=content.replaceAll(search, replacewith);
					this.setTextContent(content);
					
				}
			}
			*/
		}
		//System.out.println(replaceVarInText(this.getTextContent(),mem));
		//System.out.println(mem.toString());
		//Choose the next node
		boolean choosing=true;
		int indexNode=-1;
		int nbloop=0;
		int maxloop=10000;
		while(choosing){
			nbloop++;
			StoryNode tempNode=null;
			if (this.getTo_nodes_id().length()>0){
				String[] nodesId= this.getTo_nodes_id().split(",");
				if (nodesId.length>0){
					if (listOfChoices.size()>index){			
						tempNode= new StoryNode(listOfChoices.get(index));
					}else{
						int r=randomNumber.nextInt(nodesId.length);
						tempNode= new StoryNode(nodesId[r]);
						
					}
				}else{
					choosing=false;
				}
			}else{
				choosing=false;
			}
			
			if (tempNode!=null){
				indexNode= nodes.indexOf(tempNode);
			}
			
			
			if (indexNode>=0){
				sn=nodes.get(indexNode);
				
				if (sn.getCondition().length()>0){
					if (mem.checkCondition(sn.getCondition())==true){
						if (sn.isUnique()){
							if (!mem.getMemory().contains(sn.id)){
								choosing=false;
							}
						}else{
							choosing=false;
						}
					}
				}else{
					if (sn.isUnique()){
						if (!mem.getMemory().contains(sn.id)){
							choosing=false;
						}
					}else{
						choosing=false;
					}
				}
			}
			
			if (nbloop>maxloop){
				choosing=false;
				indexNode=-1;
				//sn=null;
			}
			
		}
		if (indexNode>=0){
			//Interprete instructions
			if (sn.isUnique()){
				if (!mem.getMemory().contains(sn.id)){
					mem.getMemory().add(sn.id);
				}
			}
			if (sn.getMemory_add().length()>0){
				mem.addMemory(sn.getMemory_add());
			}
			if (sn.getMemory_remove().length()>0){
				mem.removeMemory(sn.getMemory_remove());
			}
			mem.getGlobalMemory().add(mem.getNewListMemory());
			
			if (listOfChoices.size()<=index){
				listOfChoices.add(sn.getId());
			}
		}
		nextNode=sn;
		return sn;
	}
	public String replaceVarInText(String var,StoryMemory mem){
		String out="";
		String content= this.getTextContent();
		if (this.var.length()>0){
			String[] s=this.var.split(",");
			for (int i=0;i<s.length;i++){
				
				if (content.indexOf(s[i])>=0){
					
					String replacewith = mem.getValueFromMemory(s[i]);
					String search=s[i];
					content=content.replaceAll(search, replacewith);
					out=content;
					
				}
			}
		}else{
			out=this.getTextContent();
		}
		return out;
	}
	public StoryNode getNextNode() {
		return nextNode;
	}
	public void setNextNode(StoryNode nextNode) {
		this.nextNode = nextNode;
	}

	
}
