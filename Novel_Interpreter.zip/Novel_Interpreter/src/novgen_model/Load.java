package novgen_model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Load {
	
	public static Story LoadStory(String fileName) {
		Story story = new Story();
		File file = new File(fileName);
		// Instantiate the input stream
		InputStream insputStream = null;
		try {
			insputStream = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (insputStream != null) {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = null;
			try {
				db = dbf.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			}

			Document doc;
			try {
				doc = db.parse(insputStream);
				Element root = doc.getDocumentElement();
				story.setName(root.getAttribute("title"));
				story.setAuthor(root.getAttribute("author"));
				story.setLengthStory(Integer.valueOf(root.getAttribute("length")).intValue());
				story.setStartId(root.getAttribute("startPoint"));
				NodeList nodeList = root.getElementsByTagName("node");
				int numKeys = nodeList.getLength();
				for (int i = 0; i < numKeys; i++) {
					Node node = nodeList.item(i);
					Element elt = (Element) node;
					//(String id,String textContent,String memory_add,String memory_remove,String condition,String to_nodes_id,boolean unique,String var)
					/*
					elt_node.setAttribute("id", sn.getId());
					elt_node.setAttribute("textContent", sn.getTextContent());
					elt_node.setAttribute("memoryAdd", sn.getMemory_add());
					elt_node.setAttribute("memoryRemove", sn.getMemory_remove());
					elt_node.setAttribute("memoryCondition", sn.getCondition());
					elt_node.setAttribute("nextNodes", sn.getTo_nodes_id());
					elt_node.setAttribute("unique",String.valueOf(sn.isUnique()));
					elt_node.setAttribute("variable", sn.getVar());
					*/
					//String convert=elt.getAttribute("textContent");
					//convert=convert.replaceAll("/", "#");
					StoryNode sn=new StoryNode(elt.getAttribute("id"),elt.getAttribute("textContent"),elt.getAttribute("memoryAdd"),elt.getAttribute("memoryRemove"),elt.getAttribute("memoryCondition"),elt.getAttribute("nextNodes"),Boolean.valueOf(elt.getAttribute("unique")),elt.getAttribute("variable"));
					//StoryNode sn=new StoryNode(elt.getAttribute("id"),elt.getAttribute("textContent"),elt.getAttribute("memoryAdd"),elt.getAttribute("memoryRemove"),elt.getAttribute("memoryCondition"),elt.getAttribute("nextNodes"),Boolean.valueOf(elt.getAttribute("unique")),elt.getAttribute("variable"));
					story.getNodes().add(sn);
				}
				NodeList pathList = root.getElementsByTagName("pathChosen");
				int numKeysPath = pathList.getLength();
				for (int i = 0; i < numKeysPath; i++) {
					Node path = pathList.item(i);
					Element elt = (Element) path;
					String strPathId=elt.getAttribute("id");
					story.getListOfChoices().add(strPathId);
				}
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return story;
	}
	public static Library LoadLibrary(String fileName) {
		Library library = new Library();
		
		File file = new File(fileName);
		// Instantiate the input stream
		InputStream insputStream = null;
		try {
			insputStream = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (insputStream != null) {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = null;
			try {
				db = dbf.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			}

			Document doc;
			try {
				doc = db.parse(insputStream);
				Element root = doc.getDocumentElement();
				NodeList storiesList = root.getElementsByTagName("story");
				int numStories = storiesList.getLength();
				for (int j = 0; j < numStories; j++) {
					Node nodeStory = storiesList.item( j);
					Element eltStory = (Element) nodeStory;
					Story story = new Story();
					story.setName(eltStory.getAttribute("title"));
					story.setAuthor(eltStory.getAttribute("author"));
					story.setLengthStory(Integer.valueOf(eltStory.getAttribute("length")).intValue());
					story.setStartId(eltStory.getAttribute("startPoint"));
					NodeList nodeList = eltStory.getElementsByTagName("node");
				
					int numKeys = nodeList.getLength();
					for (int i = 0; i < numKeys; i++) {
						Node node = nodeList.item(i);
						Element elt = (Element) node;
						//(String id,String textContent,String memory_add,String memory_remove,String condition,String to_nodes_id,boolean unique,String var)
						/*
						elt_node.setAttribute("id", sn.getId());
						elt_node.setAttribute("textContent", sn.getTextContent());
						elt_node.setAttribute("memoryAdd", sn.getMemory_add());
						elt_node.setAttribute("memoryRemove", sn.getMemory_remove());
						elt_node.setAttribute("memoryCondition", sn.getCondition());
						elt_node.setAttribute("nextNodes", sn.getTo_nodes_id());
						elt_node.setAttribute("unique",String.valueOf(sn.isUnique()));
						elt_node.setAttribute("variable", sn.getVar());
						*/
						StoryNode sn=new StoryNode(elt.getAttribute("id"),elt.getAttribute("textContent"),elt.getAttribute("memoryAdd"),elt.getAttribute("memoryRemove"),elt.getAttribute("memoryCondition"),elt.getAttribute("nextNodes"),Boolean.valueOf(elt.getAttribute("unique")),elt.getAttribute("variable"));
						story.getNodes().add(sn);
					}
					NodeList pathList = root.getElementsByTagName("pathChosen");
					int numKeysPath = pathList.getLength();
					for (int i = 0; i < numKeysPath; i++) {
						Node path = pathList.item(i);
						Element elt = (Element) path;
						String strPathId=elt.getAttribute("id");
						story.getListOfChoices().add(strPathId);
					}
					library.getStories().add(story);
				}
			} catch (SAXException e) {
					e.printStackTrace();
			} catch (IOException e) {
					e.printStackTrace();
			}
			
		}
		return library;
	}
}
