package novgen_model;

public class MemoryElement {
	private String name;
	private int nb;
	
	
	public MemoryElement(String name,int nb){
		this.name=name;
		this.nb=nb;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNb() {
		return nb;
	}
	public void setNb(int nb) {
		this.nb = nb;
	}
	
	
}
