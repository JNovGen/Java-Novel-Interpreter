package novgen_model;

import java.util.ArrayList;

public class StoryMemory {
	private ArrayList<String> memory;
	private ArrayList<ArrayList<String>> globalMemory;
	public void updateMemory(int index){
		memory = new ArrayList<String>();
		if (globalMemory.get(index)!=null){
			memory.addAll(globalMemory.get(index));
		}
	}
	
	public StoryMemory(){
		globalMemory=new ArrayList<ArrayList<String>>();
		memory = new ArrayList<String>();
	}

	public ArrayList<String> getMemory() {
		return memory;
	}
	public ArrayList<String> getNewListMemory() {
		ArrayList<String> newList= new ArrayList<String>();
		for (int i=0;i<memory.size();i++){
			newList.add(new String(memory.get(i)));
		}
		return newList;
	}

	public void setMemory(ArrayList<String> memory) {
		this.memory = memory;
	}
	public void addMemory(String instr){
		String[] s= instr.split(",");
		for (int i=0;i<s.length;i++){
			String[] str_element=s[i].split("[*]");
			if (str_element.length==2){
				try {
					MemoryElement me=new MemoryElement(str_element[0],Integer.valueOf(str_element[1]).intValue());
				
					for (int j=0;j<me.getNb();j++){
						this.memory.add(me.getName());
						
					}
				}
				catch (NumberFormatException e){
					//Check if the name of a variable:
					MemoryElement me=new MemoryElement(str_element[0],getNbElementsOfAtype(str_element[1],memory));
					for (int j=0;j<me.getNb();j++){
						this.memory.add(me.getName());
						
					}
				}
				
				
			}
			if (str_element.length==1){
				String[] str=str_element[0].split("=");
				if (str.length==2){
					try {//It's a number
					int value=Integer.valueOf(str[1]).intValue();
					//removeMemory(str[0]+"*"+getNbElementsOfAtype(str[0],memory));
					removeMemory(str[0]+"*"+str[0]);//Remove of elements
					addMemory(str[0]+"*"+value);
					
					}catch (NumberFormatException e){//it's not a number
						int index=getIndexFromVarMemory(str[0]);
						if (index>=0){
							this.memory.remove(index);
						}
						this.memory.add(str_element[0]);
					}
				}
				
			}
		}
	}
	public void removeMemory(String instr){
		String[] s= instr.split(",");
		for (int i=0;i<s.length;i++){
			String[] str_element=s[i].split("[*]");
			if (str_element.length==2){
				try {
					MemoryElement me=new MemoryElement(str_element[0],Integer.valueOf(str_element[1]).intValue());
					for (int j=0;j<me.getNb();j++){
						if (this.memory.contains(me.getName())){
							this.memory.remove(me.getName());
							
						}
					}
				} catch (NumberFormatException e){
					MemoryElement me=new MemoryElement(str_element[0],getNbElementsOfAtype(str_element[1],memory));
					for (int j=0;j<me.getNb();j++){
						if (this.memory.contains(me.getName())){
							this.memory.remove(me.getName());
							
						}
					}
				}
			}
			if (str_element.length==1){
				if (this.memory.contains(str_element[0])){
					this.memory.remove(str_element[0]);
				}
			}
		}
	}
	
	public String toString(){
		String str="";
		for (int j=0;j<globalMemory.size();j++){
			ArrayList<String> tempMem= new ArrayList<String>();
			tempMem= globalMemory.get(j);
			str=str+j+"."+memToString(tempMem)+"\n";
		}
		return str;
	}
	public String memToString(ArrayList<String> list){
		String str="";
		ArrayList<String> uniqueMemList = new ArrayList<String>();
		for (int i=0;i<list.size();i++){
			if (!uniqueMemList.contains(list.get(i))){
				uniqueMemList.add(list.get(i));
			}
		}
		for (int i=0;i<uniqueMemList.size();i++){
			str=str+uniqueMemList.get(i)+"*"+getNbElementsOfAtype(uniqueMemList.get(i),list)+";";
		}
		
		return str;
	}
	public boolean checkCondition(String str){
		boolean result=false;
		String[] s=str.split(">=");
		if (s.length==2){
			String arg0=s[0];
			int nbEltsArg0=getNbElementsOfAtype(arg0,memory);
			String arg1=s[1];
			int nbEltsArg1=0;
			try {
				nbEltsArg1=Integer.valueOf(arg1).intValue();
				
			} catch (NumberFormatException e){
				nbEltsArg1=getNbElementsOfAtype(arg1,memory);
			}
			if (nbEltsArg0>=nbEltsArg1)result=true;
				
		}else{
			s=str.split("<=");
			if (s.length==2){
				String arg0=s[0];
				int nbEltsArg0=getNbElementsOfAtype(arg0,memory);
				String arg1=s[1];
				int nbEltsArg1=0;
				try{ 
					nbEltsArg1=Integer.valueOf(arg1).intValue();
				
				} catch (NumberFormatException e){
					nbEltsArg1=getNbElementsOfAtype(arg1,memory);
				}
				
				if (nbEltsArg0<=nbEltsArg1)result=true;
			}else{
				s=str.split("<");
				if (s.length==2){
					String arg0=s[0];
					int nbEltsArg0=getNbElementsOfAtype(arg0,memory);
					String arg1=s[1];
					int nbEltsArg1=0;
					try{
						nbEltsArg1=Integer.valueOf(arg1).intValue();
					} catch (NumberFormatException e){
						nbEltsArg1=getNbElementsOfAtype(arg1,memory);
					}
					if (nbEltsArg0<nbEltsArg1)result=true;
				} else {
					s=str.split(">");
					if (s.length==2){
						String arg0=s[0];
						int nbEltsArg0=getNbElementsOfAtype(arg0,memory);
						String arg1=s[1];
						int nbEltsArg1=0;
						try {
							nbEltsArg1=Integer.valueOf(arg1).intValue();
							
						} catch (NumberFormatException e){
							nbEltsArg1=getNbElementsOfAtype(arg1,memory);
						}
						if (nbEltsArg0>nbEltsArg1)result=true;	
					}else{
						s=str.split("=");
						if (s.length==2){
							String arg0=s[0];
							int nbEltsArg0=getNbElementsOfAtype(arg0,memory);
							String arg1=s[1];
							int nbEltsArg1=0;
							try {
								nbEltsArg1=Integer.valueOf(arg1).intValue();
								
							} catch (NumberFormatException e){
								nbEltsArg1=getNbElementsOfAtype(arg1,memory);
							}
							if (nbEltsArg0==nbEltsArg1)result=true;	
						}
					}
				}
			}
		}
		return result;
	}
	public int getNbElementsOfAtype(String eltName,ArrayList<String> list){
		int nb=0;
		for (int i=0;i<list.size();i++){
			if (list.get(i).equals(eltName)){
				nb++;
			}
		}
		return nb;
	}
	public String getValueFromMemory(String varname){
		String s="";
		for (int i=0;i<this.memory.size();i++){
			String[] str=this.memory.get(i).split("=");
			if (str.length==2){
				if (str[0].equals(varname)){
					s=str[1];
					break;
				}
			}
			if (str.length==1){
				if (str[0].equals(varname)){
					s=""+getNbElementsOfAtype(str[0],memory);
					break;
				}
			}
		}
		return s;
	}
	public int getIndexFromVarMemory(String varname){
		int index=-1;
		for (int i=0;i<this.memory.size();i++){
			String[] str=this.memory.get(i).split("=");
			if (str.length==2){
				if (str[0].equals(varname)){
					index=i;
					break;
				}
			}
		}
		return index;
	}

	public ArrayList<ArrayList<String>> getGlobalMemory() {
		return globalMemory;
	}

	public void setGlobalMemory(ArrayList<ArrayList<String>> globalMemory) {
		this.globalMemory = globalMemory;
	}

	
	
}
