package novgen_model;

import java.util.ArrayList;

public class Library {
	private ArrayList<Story> stories;

	public Library(){
		stories= new ArrayList<Story>();
	}
	public ArrayList<Story> getStories() {
		return stories;
	}

	public void setStories(ArrayList<Story> libraries) {
		this.stories = libraries;
	}
	
	
}
