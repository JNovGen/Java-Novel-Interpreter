package launch;
import novgen_model.Library;
import novgen_model.Load;
import novgen_model.Story;
import novgen_model.StoryNode;
import view.FrameInfo;
import view.StoryEditorMainWindow;
import controller.Controller;


public class Launch {

	public static void main(String[] args) {
		
		Story s=new Story();
		Library library= new Library();
		StoryEditorMainWindow smw= new StoryEditorMainWindow(s);
		Controller c= new Controller(s,smw,library);
		smw.setController(c);
		FrameInfo f= new FrameInfo();
	}

}
